require "convert_quran"

local collected_suri = load_quran()

for i, rec in ipairs(collected_suri) do
  
  local bsml_str = "[ ]"
  if rec.bsml then
    bsml_str = "[+]"
  end

  local ayat_count = #rec.ayats

  print(string.format("%03d bsml%s ayats: %003d  %s (%s)", i, bsml_str,
      ayat_count, rec.ar_name, rec.ru_name))
end

gen_full_quran_html(collected_suri, "quran_out.html")
gen_paged_quran_html(collected_suri)

