
local SURI_AYAT_COUNT_STR = [[
A 1 7
A 2 286
A 3 200
A 4 176
A 5 120
A 6 165
A 7 206
A 8 75
A 9 129
A 10 109
A 11 123
A 12 111
A 13 43
A 14 52
A 15 99
A 16 128
A 17 111
A 18 110
A 19 98
A 20 135
A 21 112
A 22 78
A 23 118
A 24 64
A 25 77
A 26 227
A 27 93
A 28 88
A 29 69
A 30 60
A 31 34
A 32 30
A 33 73
A 34 54
A 35 45
A 36 83
A 37 182
A 38 88
A 39 75
A 40 85
A 41 54
A 42 53
A 43 89
A 44 59
A 45 37
A 46 35
A 47 38
A 48 29
A 49 18
A 50 45
A 51 60
A 52 49
A 53 62
A 54 55
A 55 78
A 56 96
A 57 29
A 58 22
A 59 24
A 60 13
A 61 14
A 62 11
A 63 11
A 64 18
A 65 12
A 66 12
A 67 30
A 68 52
A 69 52
A 70 44
A 71 28
A 72 28
A 73 20
A 74 56
A 75 40
A 76 31
A 77 50
A 78 40
A 79 46
A 80 42
A 81 29
A 82 19
A 83 36
A 84 25
A 85 22
A 86 17
A 87 19
A 88 26
A 89 30
A 90 20
A 91 15
A 92 21
A 93 11
A 94 8
A 95 8
A 96 19
A 97 5
A 98 8
A 99 8
A 100 11
A 101 11
A 102 8
A 103 3
A 104 9
A 105 5
A 106 4
A 107 7
A 108 3
A 109 6
A 110 3
A 111 5
A 112 4
A 113 5
A 114 6
]]

local NO_BSML_SURI = {
  [1] = true,
  [9] = true,
}

local BSML_STR = "Во имя Аллаха, Милостивого, Милосердного!"
local QURAN_FNAME = "quran.txt"
local TITLE1 = "КОРАН"
local TITLE2 = "Перевод смыслов Э. Кулиева"

local collected_suri = {}

local g_suri_no = nil
local g_suri_ar_name = nil
local g_suri_ru_name = nil
local g_suri_ayats = {}
local g_suri_bsml = false

local function push_suri ()
  collected_suri[assert(g_suri_no)] = {
    ar_name = assert(g_suri_ar_name),
    ru_name = assert(g_suri_ru_name),
    no = assert(g_suri_no),
    bsml = g_suri_bsml,
    ayats = assert(g_suri_ayats),
  }
end

local function reset_suri ()
  g_suri_no = nil
  g_suri_ar_name = nil
  g_suri_ru_name = nil
  g_suri_ayats = {}
  g_suri_bsml = false
end

local function reset_state ()
  collected_suri = {}
  reset_suri()
end

function load_quran ()

  local line_no = 0
  reset_state()

  -- перебор строк в файле с текстом Корана
  for l in io.lines(QURAN_FNAME) do

    line_no = line_no + 1

    -- обработка только непустых строк
    if not string.match(l, "^%s*$") then

      -- Сура, строка 1 (номер суры, араб. звуч. имя)
      if string.match(l, "Сура (%d+) «(.-)»") then

        local suri_no, suri_ar_name = string.match(l, "Сура (%d+) «(.-)»")
        suri_no = assert(tonumber(suri_no))

        if suri_no > 1 then
          push_suri()
        end
        reset_suri()

        g_suri_no = assert(tonumber(suri_no))
        g_suri_ar_name = suri_ar_name

      -- Сура, строка 2 (рус. имя)
      elseif string.match(l, "^%s*%(«(.-)»%)%s*$") then
        local suri_ru_name = string.match(l, "^%s*%(«(.-)»%)%s*$")
        g_suri_ru_name = suri_ru_name

      -- аят, "номер. текст"
      elseif string.match(l, "^(%d+)%.%s+(.+)$") then
        local ayat_no, ayat_text = string.match(l, "^(%d+)%.%s+(.+)$")
        ayat_no = assert(tonumber(ayat_no))

        g_suri_ayats[ayat_no] = {
          text = ayat_text,
        }

      -- басмала в начале суры
      elseif l == BSML_STR then
        g_suri_bsml = true

      -- строки заголовка книги в конкретном документе. игнорировать.
      elseif l == TITLE1 or l == TITLE2 then
        -- pass

      -- неопознанная строка
      else
        error(string.format("cannot parse string #%d: \"%s\"", line_no, l))
      end
    end
  end
  push_suri()

  -- котрольная проверка количества аятов в суре
  for d1, d2 in string.gmatch(SURI_AYAT_COUNT_STR, "A%s+(%d+)%s+(%d+)") do
    local no = assert(tonumber(d1))
    local count = assert(tonumber(d2))
    if #collected_suri[no].ayats ~= count then
      error(string.format("ayat count mismatch for suri %d: %d != %d",
          no, #collected_suri[no].ayats, count))
    end

    local rec = collected_suri[no]
    for j = 1, count do
      if not rec.ayats[j]
      or not rec.ayats[j].text
      then
        error(string.format("no %d:%d ayat", no, j))
      end
    end
  end

  -- котрольная проверка басмалы в сурах
  for i, rec in ipairs(collected_suri) do
    local expected_bsml = not NO_BSML_SURI[i]
    if rec.bsml ~= expected_bsml then
      error(string.format("unexpected bsml for suri %d: %s != %s", i,
          tostring(expected_bsml), tostring(rec.bsml)))
    end
  end

  -- контрольная проверка количества сур
  if #collected_suri ~= 114 then
    error("unexpected suri count: %d != 114", #collected_suri)
  end

  return collected_suri
end

------------------------------------------------------------------------------

local SURI_LAT_NAMES_STR = [[
AA 001-fatiha
AA 002-baqara
AA 003-ali-imran
AA 004-nisa
AA 005-maida
AA 006-anam
AA 007-araf
AA 008-anfal
AA 009-tawba
AA 010-yunus
AA 011-hud
AA 012-yusuf
AA 013-ra1d
AA 014-ibrahim
AA 015-hijr
AA 016-nahl
AA 017-isra
AA 018-kahf
AA 019-maryam
AA 020-taha
AA 021-anbiya
AA 022-haj
AA 023-muminun
AA 024-nur
AA 025-furqan
AA 026-shuara
AA 027-naml
AA 028-qasas
AA 029-ankabut
AA 030-rum
AA 031-luqman
AA 032-sajda
AA 033-ahzab
AA 034-saba
AA 035-fatir
AA 036-yasin
AA 037-saffat
AA 038-sod
AA 039-zumar
AA 040-gafir
AA 041-fussilat
AA 042-shura
AA 043-zuhruf
AA 044-duhan
AA 045-jasiya
AA 046-ahkaf
AA 047-muhammad
AA 048-fath
AA 049-hujurat
AA 050-qaf
AA 051-zariyat
AA 052-tur
AA 053-najm
AA 054-qamar
AA 055-rahman
AA 056-waqia
AA 057-hadid
AA 058-mujadila
AA 059-hashr
AA 060-mumtahana
AA 061-saff
AA 062-juma
AA 063-munafiqun
AA 064-taghabun
AA 065-talaq
AA 066-tahrim
AA 067-mulk
AA 068-qalam
AA 069-haqqa
AA 070-maarij
AA 071-nuh
AA 072-jin
AA 073-muzzammil
AA 074-muddassir
AA 075-qiyama
AA 076-insan
AA 077-mursalat
AA 078-naba
AA 079-naziat
AA 080-abasa
AA 081-takwir
AA 082-infitar
AA 083-mutaffifin
AA 084-inshiqaq
AA 085-buruj
AA 086-tariq
AA 087-ala
AA 088-gashiya
AA 089-fajr
AA 090-balad
AA 091-shams
AA 092-layl
AA 093-duha
AA 094-inshirah
AA 095-tin
AA 096-alaq
AA 097-qadr
AA 098-bayyina
AA 099-zalzala
AA 100-adiyat
AA 101-qaria
AA 102-takasur
AA 103-asr
AA 104-humaza
AA 105-fil
AA 106-quraysh
AA 107-maun
AA 108-kawsar
AA 109-kafirun
AA 110-nasr
AA 111-masad
AA 112-ihlas
AA 113-falaq
AA 114-nas
]]

local QURAN_PAGE_STYLE = [[
html {
	/* background-color: #F8F8F8 ; */
}

body {
	background-color: #FFFFFF;
	color: #151515;
	font-family: Helvetica, Arial, sans-serif ;
	text-align: left;
	line-height: 1.15;
	margin: 16px auto;
	padding: 32px;
	/* border: solid #ccc 1px ;
	border-radius: 20px ;
	max-width: 70em ;*/
	width: 90% ;
}

h1, h2, h3, h4 {
	color: #151515;
	font-family: Verdana, Geneva, sans-serif;
	font-weight: normal;
	font-style: normal;
	text-align: left;
}

h1 {
	font-size: 28pt;
}

h1 img {
	vertical-align: text-bottom;
}

a {
	text-decoration: none;
}

a:link {
	color: #007070;
}

a:link:hover, a:visited:hover {
	background-color: #CCDFDF;
	color: #007070;
	border-radius: 4px;
}

a:link:active, a:visited:active {
	color: #050000;
}

div.menubar {
	padding-bottom: 0.5em ;
}

p.menubar {
	margin-left: 2.5em ;
}

.menubar a:hover  {
	margin: -3px -3px -3px -3px ;
	padding: 3px  3px  3px  3px ;
	border-radius: 4px ;
}

:target {
	background-color: #F0F0F0 ;
	margin: -8px ;
	padding: 8px ;
	border-radius: 8px ;
	outline: none ;
}

hr {
	display: none ;
}

.navybar {
  background-color: #009090;
}

table hr {
	background-color: #a0a0a0 ;
	color: #a0a0a0 ;
	border: 0 ;
	height: 1px ;
	display: block ;
}

.footer {
	color: gray ;
	font-size: x-small ;
	text-transform: lowercase ;
}

input[type=text] {
	border: solid #a0a0a0 2px ;
	border-radius: 2em ;
	background-image: url('images/search.png') ;
	background-repeat: no-repeat ;
	background-position: 4px center ;
	padding-left: 20px ;
	height: 2em ;
}

pre.session {
	background-color: #F8F8F8 ;
	padding: 1em ;
	border-radius: 8px ;
}

table {
	border: none ;
	border-spacing: 0 ;
	border-collapse: collapse ;
}

td {
	padding: 0 ;
	margin: 0 ;
}

td.gutter {
	width: 4% ;
}

table.columns td {
	vertical-align: top ;
	padding-bottom: 1em ;
	text-align: left ;
	line-height: 1.25 ;
}

table.book td {
	vertical-align: top ;
}

table.book td.cover {
	padding-right: 1em ;
}

table.book img {
	border: solid #008080 1px ;
}

table.book span {
	font-size: small ;
	text-align: left ;
	display: block ;
	margin-top: 0.25em ;
}

p.logos a:link:hover, p.logos a:visited:hover {
	background-color: inherit ;
}

img {
	background-color: white ;
}
]]

function gen_full_quran_html (collected_suri, fname)
  local fd = assert(io.open(fname, "wb"))
  local function write (...)
    assert(fd:write(...))
  end
  local function writef (...)
    return write(string.format(...))
  end

  write(
    "<html>"
    .. "<head>"
    .. "<title>Коран</title>"
    .. "<style>" .. QURAN_PAGE_STYLE .. "</style>"
    .. "</head>"
    .. "<body>"
  )

  write("<h1>" .. TITLE1 .. "</h1>\n")
  write("<h3>" .. TITLE2 .. "</h3>\n")

  -- сгенерировать оглавление
  write("<h3>ОГЛАВЛЕНИЕ:</h3><ul>\n")
  for i, rec in ipairs(collected_suri) do
    writef("<li>\n", i)
    writef("<a href='#sura_%d'>Сура %d - %s (%s)</a>\n", i, i, rec.ar_name,
        rec.ru_name)
    write("</li>\n")
  end
  write("</ul>\n")

  -- дописать тела сур
  for i, rec in ipairs(collected_suri) do

    write("<h3>&nbsp;</h3>\n")

    writef("<h2 id='sura_%d'>Сура %d %s (%s)</h2>\n", i, i, rec.ar_name,
        rec.ru_name)

    if rec.bsml then
      writef("<p>%s</p>\n", BSML_STR)
    end

    for j, rec2 in ipairs(rec.ayats) do
      writef(
        "<p id='ayat_%d_%d'><a href='#ayat_%d_%d'>%d:%d.</a> %s</p>\n",
        i, j,
        i, j,
        i, j,
        rec2.text
      )
    end
  end

  -- завершить документ
  write("</body></html>")
  assert(fd:close())
end

local lat_names = nil
local function gen_suri_fname (suri_no)

  if not lat_names then
    lat_names = {}
    for d1, d2 in string.gmatch(SURI_LAT_NAMES_STR, "AA%s+(%d+)%-(%S+)") do
      local no = assert(tonumber(d1))
      local name = d2
      lat_names[no] = name
    end
  end

  local suri_fname = string.format("%03d-%s.html", suri_no, lat_names[suri_no])
  return suri_fname
end

function gen_suri_page_html (collected_suri, no)

  local fname = "doc/" .. gen_suri_fname(no)

  local fd = assert(io.open(fname, "wb"))
  local function write (...)
    assert(fd:write(...))
  end
  local function writef (...)
    return write(string.format(...))
  end

  -- генерировать навигацию
  local function gen_nav ()
    write("<p>")
    if no > 1 then
      local prev_no = no - 1
      local prev_fname = gen_suri_fname(prev_no)
      writef("<a href='%s#sura_%d'>&lt; предыдущая</a>", prev_fname, prev_no)
      write(string.rep("&nbsp;", 3))
    end
    write("<a href='000-index.html'>к оглавлению</a>")
    if no < 114 then
      local next_no = no + 1
      local next_fname = gen_suri_fname(next_no)
      write(string.rep("&nbsp;", 3))
      writef("<a href='%s#sura_%d'>следующая &gt;</a>", next_fname, next_no)
    end
    write("</p>")
  end

  local rec = collected_suri[no]

  write(
    "<html>"
    .. "<head>"
    .. string.format("<title>Сура %d %s (%s)</title>", no, rec.ar_name,
        rec.ru_name)
    .. "<style>" .. QURAN_PAGE_STYLE .. "</style>"
    .. "</head>"
    .. "<body>"
  )

  -- генерировать навигацию
  gen_nav()

  writef("<h2 id='sura_%d'>Сура %d %s (%s)</h2>", no, no, rec.ar_name,
        rec.ru_name)

  if rec.bsml then
    writef("<p>%s</p>\n", BSML_STR)
  end

  for j, rec2 in ipairs(rec.ayats) do
    writef(
      "<p id='ayat_%d_%d'><a href='#ayat_%d_%d'>%d:%d.</a> %s</p>\n",
      no, j,
      no, j,
      no, j,
      rec2.text
    )
  end

  gen_nav()

  -- завершить документ
  write("</body></html>")
  assert(fd:close())
end

function gen_paged_quran_html (collected_suri)

  os.execute("rm -r doc")
  if 0 ~= os.execute("mkdir doc") then
    error("cannot create doc/ directory")
  end

  local fd = assert(io.open("doc/000-index.html", "wb"))
  local function write (...)
    assert(fd:write(...))
  end
  local function writef (...)
    return write(string.format(...))
  end

  write(
    "<html>"
    .. "<head>"
    .. "<title>Коран</title>"
    .. "<style>" .. QURAN_PAGE_STYLE .. "</style>"
    .. "</head>"
    .. "<body>"
  )

  write("<h1>" .. TITLE1 .. "</h1>\n")
  write("<h3>" .. TITLE2 .. "</h3>\n")

  -- сгенерировать оглавление
  write("<h3>ОГЛАВЛЕНИЕ:</h3><ul>\n")
  for i, rec in ipairs(collected_suri) do

    local suri_fname = gen_suri_fname(i)

    writef("<li>\n", i)
    writef("<a href='%s#sura_%d'>Сура %d - %s (%s)</a>\n", suri_fname, i, i,
        rec.ar_name, rec.ru_name)
    write("</li>\n")

    gen_suri_page_html(collected_suri, i)
  end
  write("</ul>\n")

  -- завершить документ
  write("</body></html>")
  assert(fd:close())
end

return true

