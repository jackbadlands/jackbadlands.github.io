
function rtrim (str)
	return string.match(str, "^(.-)%s*$") or str
end

function ltrim (str)
	return string.match(str, "^%s*(.-)$") or str
end

function trim (str)
	return string.match(str, "^%s*(.-)%s*$") or str
end

return {
	rtrim = rtrim,
	ltrim = ltrim,
	trim = trim,
}

