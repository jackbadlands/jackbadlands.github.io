package.path = "lua/?.lua;lua/?/init.lua;" .. package.path
package.cpath = "lua/?.so;lua/?/init.so;" .. package.cpath
return true

